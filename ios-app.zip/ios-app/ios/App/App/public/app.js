document.getElementById("btn").onclick = () => {
  alert("Button clicked!");
};
